package com.example.mobiletechnologygroupassignment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Activity7 extends AppCompatActivity {

    private String filename;
    private String reader;
    private String text;
    private String imageUriString;
    private String imageData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity7);

        TextView textTitle = findViewById(R.id.textActivity7Title);
        TextView textResult = findViewById(R.id.textActivity7Result);
        ImageView imageView = findViewById(R.id.imageActivity7);

        Intent intent = getIntent();
        if (intent != null) {
            filename = intent.getStringExtra("FILENAME");
            reader = intent.getStringExtra("READER");
            text = intent.getStringExtra("TEXT");
            imageUriString = intent.getStringExtra("IMAGE_URI");
            imageData = intent.getStringExtra("IMAGE_DATA");

            textTitle.setText(reader != null ? reader : "Analysed Image");
            textResult.setText(text);
            
            if (imageData != null && !imageData.isEmpty()) {
                byte[] decodedString = Base64.decode(imageData, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                imageView.setImageBitmap(decodedByte);
            } else if (imageUriString != null && !imageUriString.isEmpty()) {
                imageView.setImageURI(Uri.parse(imageUriString));
            }
        }
    }

    public void onEditClicked(View view) {
        Intent intent = new Intent(this, Activity5.class);
        intent.putExtra("IS_EDIT", true);
        intent.putExtra("FILENAME", filename);
        intent.putExtra("READER_TYPE", reader);
        intent.putExtra("RESULT_TEXT", text);
        intent.putExtra("IMAGE_URI", imageUriString);
        intent.putExtra("IMAGE_DATA", imageData);
        startActivity(intent);
    }

    public void onDeleteClicked(View view) {
        if (filename != null) {
            DatabaseReference database = FirebaseDatabase.getInstance().getReference("Storage");
            database.child(filename).removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(Activity7.this, "Item deleted", Toast.LENGTH_SHORT).show();
                        onCancelClicked(null);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(Activity7.this, "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    public void onCancelClicked(View view) {
        Intent intent = new Intent(this, Activity6.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}
