package com.example.mobiletechnologygroupassignment;

public class AnalysedImage {
    public String filename;
    public String reader;
    public String text;
    public String imageUri;
    public String imageData;
    public boolean isFromGallery;

    public AnalysedImage() {
    }

    public AnalysedImage(String filename, String reader, String text, String imageUri, String imageData, boolean isFromGallery) {
        this.filename = filename;
        this.reader = reader;
        this.text = text;
        this.imageUri = imageUri;
        this.imageData = imageData;
        this.isFromGallery = isFromGallery;
    }
}
