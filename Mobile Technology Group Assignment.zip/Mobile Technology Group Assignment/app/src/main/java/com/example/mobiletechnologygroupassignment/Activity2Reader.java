package com.example.mobiletechnologygroupassignment;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.Locale;

public class Activity2Reader extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;
    private TextView textViewTitle;
    private Button buttonEditResult;
    private Button buttonOpenCamera;
    private Button buttonLoadImage;
    private String readerMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity2_reader);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageReaderPreview);
        textViewOutput = findViewById(R.id.textReaderOutput);
        textViewTitle = findViewById(R.id.textReaderTitle);
        buttonEditResult = findViewById(R.id.buttonReaderEditResult);
        buttonOpenCamera = findViewById(R.id.buttonReaderOpenCamera);
        buttonLoadImage = findViewById(R.id.buttonReaderLoadImage);

        readerMode = getIntent().getStringExtra("READER_MODE");
        if (readerMode == null) readerMode = "Text Reader";

        updateUIBasedOnMode();
    }

    private void updateUIBasedOnMode() {
        switch (readerMode) {
            case "Barcode Reader":
                textViewTitle.setText("Barcode Reader");
                imageView.setImageResource(R.drawable.barcode);
                break;
            case "Content Reader":
                textViewTitle.setText("Content Reader");
                imageView.setImageResource(R.drawable.content);
                break;
            case "Text Reader":
            default:
                textViewTitle.setText("Text Reader");
                imageView.setImageResource(R.drawable.text);
                break;
        }
    }

    public void openCamera(View view) {
        if (!checkPermission())
            return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    if (result.getData() != null && result.getData().getData() != null)
                        imageFileUri = result.getData().getData();
                    imageView.setImageURI(imageFileUri);
                    textViewOutput.setText("");
                    InputImage image = null;
                    try {
                        image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (image != null) {
                        processImage(image);
                    }
                }
            });

    private void processImage(InputImage image) {
        textViewTitle.setText(readerMode);
        buttonEditResult.setVisibility(View.VISIBLE);
        
        switch (readerMode) {
            case "Barcode Reader":
                processBarcode(image);
                break;
            case "Content Reader":
                processContent(image);
                break;
            case "Text Reader":
            default:
                processText(image);
                break;
        }
    }

    private void processBarcode(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    textViewOutput.setText("");
                    textViewOutput.append(Html.fromHtml("<font color='#3F51B5'><b>Detected barcode:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                    if (barcodes.isEmpty()) {
                        textViewOutput.append(" Barcode not found.\n");
                    } else {
                        int counter = 1;
                        for (Barcode barcode : barcodes) {
                            textViewOutput.append(counter + ". " + barcode.getRawValue() + "\n");
                            counter++;
                        }
                    }
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processContent(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    textViewOutput.setText("");
                    textViewOutput.append(Html.fromHtml("<font color='#3F51B5'><b>Recognised image content:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                    if (labels.isEmpty()) {
                        textViewOutput.append("Nothing found in the image\n");
                        return;
                    }
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        textViewOutput.append(counter + ". " + label.getText() +
                                " (" + String.format(Locale.getDefault(), "%.1f", label.getConfidence() * 100.0f) + "% confidence)\n");
                        counter++;
                    }
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processText(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    textViewOutput.setText("");
                    textViewOutput.append(Html.fromHtml("<font color='#3F51B5'><b>Extracted text:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                    String resultText = visionText.getText();
                    if (resultText.length() > 1) {
                        textViewOutput.append(" 1. " + resultText + "\n");
                    } else {
                        textViewOutput.append(" No text found.\n");
                    }
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    public void editResult(View view) {
        Intent intent = new Intent(Activity2Reader.this, Activity5.class);
        intent.putExtra("READER_TYPE", readerMode);
        intent.putExtra("RESULT_TEXT", textViewOutput.getText().toString());
        if (imageFileUri != null) {
            intent.putExtra("IMAGE_URI", imageFileUri.toString());
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        startActivity(intent);
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }
}
