package com.example.mobiletechnologygroupassignment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class AnalysedImageAdapter extends ArrayAdapter<AnalysedImage> {

    public AnalysedImageAdapter(@NonNull Context context, @NonNull List<AnalysedImage> objects) {
        super(context, 0, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity6_list_item_analysed, parent, false);
        }

        AnalysedImage item = getItem(position);

        ImageView imageView = convertView.findViewById(R.id.imageItemAnalysed);
        TextView textView = convertView.findViewById(R.id.textItemReaderName);

        if (item != null) {
            if (position % 2 == 0) {
                convertView.setBackgroundColor(Color.LTGRAY);
            } else {
                convertView.setBackgroundColor(Color.WHITE);
            }

            textView.setText(item.filename);
            
            if (item.imageData != null && !item.imageData.isEmpty()) {
                byte[] decodedString = Base64.decode(item.imageData, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                imageView.setImageBitmap(decodedByte);
            } else if (item.imageUri != null && !item.imageUri.isEmpty()) {
                try {
                    imageView.setImageURI(Uri.parse(item.imageUri));
                } catch (SecurityException e) {
                    imageView.setImageResource(android.R.drawable.ic_menu_gallery);
                }
            } else {
                imageView.setImageResource(android.R.drawable.ic_menu_gallery);
            }

            convertView.setOnClickListener(v -> {
                Intent intent = new Intent(getContext(), Activity7.class);
                intent.putExtra("FILENAME", item.filename);
                intent.putExtra("READER", item.reader);
                intent.putExtra("TEXT", item.text);
                intent.putExtra("IMAGE_URI", item.imageUri);
                intent.putExtra("IMAGE_DATA", item.imageData);
                getContext().startActivity(intent);
            });
        }

        return convertView;
    }
}
