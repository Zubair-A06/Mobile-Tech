package com.example.mobiletechnologygroupassignment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Activity5 extends AppCompatActivity {

    private EditText editTitle;
    private EditText editResult;
    private ImageView imageView;
    private Uri imageUri;
    private String readerType;
    private boolean isEditMode = false;
    private String originalFilename;
    private String base64Image = "";
    private boolean isFromGallery = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity5);

        editTitle = findViewById(R.id.editActivity5Title);
        editResult = findViewById(R.id.editActivity5Result);
        imageView = findViewById(R.id.imageActivity5);

        Intent intent = getIntent();
        if (intent != null) {
            isEditMode = intent.getBooleanExtra("IS_EDIT", false);
            isFromGallery = isEditMode;
            readerType = intent.getStringExtra("READER_TYPE");
            String resultText = intent.getStringExtra("RESULT_TEXT");
            String imageUriString = intent.getStringExtra("IMAGE_URI");
            base64Image = intent.getStringExtra("IMAGE_DATA");

            if (isEditMode) {
                originalFilename = intent.getStringExtra("FILENAME");
                editTitle.setText(originalFilename);
                editResult.setText(resultText);
            } else {
                String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
                editTitle.setText(timestamp);
                editResult.setText(resultText);
            }

            if (imageUriString != null) {
                imageUri = Uri.parse(imageUriString);
                imageView.setImageURI(imageUri);
            } else if (base64Image != null && !base64Image.isEmpty()) {
                decodeBase64AndSetImage(base64Image);
            }
        }
    }

    private void decodeBase64AndSetImage(String base64) {
        byte[] decodedString = Base64.decode(base64, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);
    }

    private String encodeImageToBase64(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, outputStream);
            byte[] byteArray = outputStream.toByteArray();
            return Base64.encodeToString(byteArray, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private String saveImageToInternalStorage(Uri uri, String filename) {
        if (uri.toString().startsWith("file:///data/user/0/")) {
            return uri.toString();
        }
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File file = new File(getFilesDir(), filename + ".jpg");
            OutputStream outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            return Uri.fromFile(file).toString();
        } catch (IOException e) {
            e.printStackTrace();
            return uri.toString();
        }
    }

    public void saveData(View view) {
        String editedTitle = editTitle.getText().toString();
        String editedText = editResult.getText().toString();
        
        String filename = editedTitle; 
        String internalImageUri = (imageUri != null) ? saveImageToInternalStorage(imageUri, filename) : "";
        
        if (imageUri != null && !imageUri.toString().startsWith("file:///data/user/0/")) {
            base64Image = encodeImageToBase64(imageUri);
        }

        AnalysedImage analysedImage = new AnalysedImage(filename, readerType, editedText, internalImageUri, base64Image, isFromGallery);

        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Storage");
        
        database.child(filename).setValue(analysedImage)
                .addOnSuccessListener(aVoid -> {
                    if (isEditMode && !filename.equals(originalFilename)) {
                        database.child(originalFilename).removeValue();
                    }
                    Toast.makeText(Activity5.this, "Data saved", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Activity5.this, Activity6.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(Activity5.this, "Failed to save: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
