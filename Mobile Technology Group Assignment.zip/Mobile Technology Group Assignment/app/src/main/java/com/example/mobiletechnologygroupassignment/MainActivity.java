package com.example.mobiletechnologygroupassignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton imageButton = findViewById(R.id.imageButtonBarcodeReader);
        imageButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Activity2Reader.class);
            intent.putExtra("READER_MODE", "Barcode Reader");
            startActivity(intent);
        });

        ImageButton imageButton2 = findViewById(R.id.imageButtonContentReader);
        imageButton2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Activity2Reader.class);
            intent.putExtra("READER_MODE", "Content Reader");
            startActivity(intent);
        });

        ImageButton imageButton3 = findViewById(R.id.imageButtonTextReader);
        imageButton3.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Activity2Reader.class);
            intent.putExtra("READER_MODE", "Text Reader");
            startActivity(intent);
        });

        Button buttonList = findViewById(R.id.buttonListOfAnalysedImages);
        buttonList.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Activity6.class));
        });
    }
}